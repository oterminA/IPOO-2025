<?php
include_once 'AlumnoFai.php';

$objAlumno = new AlumnoFai("DNI 23432154", "Damien", "Thorn", "8765");
echo $objAlumno;

?>