<?php
include_once 'Persona.php';

//Se le puede pedir por pantalla los datos al usuario, pero para que sea más rápido los dejo seateados yo:
$persona1 = new Persona("Pepe", "Gomez", "DNI", 17876543);

?>